# frozen_string_literal: true

module Bootstrap
  VERSION       = '5.2.2'
  BOOTSTRAP_SHA = '961d5ff9844372a4e294980c667bbe7e0651cdeb'
end
