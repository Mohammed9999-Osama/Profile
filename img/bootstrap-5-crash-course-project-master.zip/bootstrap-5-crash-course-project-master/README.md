[![Watch tutorial here](https://img.youtube.com/vi/jdAjQykqICY/0.jpg)](https://www.youtube.com/watch?v=jdAjQykqICY)

# Bootstrap 5.2 Crash Course Project -- [Watch tutorial here](https://www.youtube.com/watch?v=jdAjQykqICY)

Final code for the example project in the Bootstrap 5 crash course tutorial.

## Premium Courses
[Professional CSS](https://bytegrad.com/courses/professional-css) &
[Professional JavaScript](https://bytegrad.com/courses/professional-javascript)
